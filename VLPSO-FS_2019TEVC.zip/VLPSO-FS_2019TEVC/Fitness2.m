% Notation: This fitness function is for demonstration 

function cost = Fitness2(train_matrix,test_matrix,X)
if sum(X == 1) == 0
    cost = 1;
else
    train_feat = train_matrix(:,1:1:end-1);
    train_label = train_matrix(:,end);
    test_feat = test_matrix(:,1:1:end-1);
    test_label = test_matrix(:,end);
    [classes,~] = unique(train_label,'stable');
    cost = jwrapperKNN(train_feat(:, X == 1),train_label,test_feat(:, X == 1),test_label,classes);
end
end


function error = jwrapperKNN(xtrain,ytrain,xvalid,yvalid,classes)
%---// Parameter setting for k-value of KNN //
k = 3; 

% xtrain = sFeat(HO.training == 1,:);
% ytrain = label(HO.training == 1); 
% xvalid = sFeat(HO.test == 1,:); 
% yvalid = label(HO.test == 1); 

Model     = fitcknn(xtrain,ytrain,'NumNeighbors',k); 
pred      = predict(Model,xvalid);
num_valid = length(yvalid); 
num_class = length(classes);
corr_class = zeros(num_class,2);
% correct   = 0;
minus = pred - yvalid;
for i = 1:num_valid
    pos = find(yvalid(i)==classes);
    corr_class(pos,1) = corr_class(pos,1)+1;
    if minus(i) == 0
        corr_class(pos,2) = corr_class(pos,2)+1;
    end
end
Acc   = sum(corr_class(:,2) ./ corr_class(:,1))/num_class; 
error = 1 - Acc;
% if error == 0
%     a=1
% end
end

