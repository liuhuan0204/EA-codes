clc;
clear;


fold = 10;
%## paths
WEKA_HOME = '/Applications/MATLAB_R2020a.app/java/jar/';
javaaddpath([WEKA_HOME 'weka-stable-3.6.6.jar']);
fName = './DLBCL.arff';
% fName = './Parkinson.arff';



%## read file
loader = weka.core.converters.ArffLoader();
loader.setFile( java.io.File(fName) );
D = loader.getDataSet();
D.setClassIndex( D.numAttributes()-1 );
javaaddpath([WEKA_HOME 'util.jar']);
D.randomize(java.util.Random(1));
D.stratify(10);
err=zeros(1,fold);
for fi = 0:1:fold-1
    train = D.trainCV(10, fi);
    test = D.testCV(10, fi);
    [gbest,gbestval,gbestvals]=VLPSO(D.numAttributes(),train,test);
    err(fi+1) = gbest;
end