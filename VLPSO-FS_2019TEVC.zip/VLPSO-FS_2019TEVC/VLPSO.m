function [gbest,gbestval,gbestvals] = VLPSO(feature_num,train,test)
    %初始化参数
    if (feature_num-1)/20>300
        popSize = 300;
    elseif (feature_num-1)/20<=100
        popSize = 100;
    else
        popSize = floor((feature_num-1)/20);
    end
%     popSize=30;
    MaxIter = 100;
    c1 = 1.49445;
    c2 = 1.49445;
    w=0.9-(1:MaxIter)*(0.4/MaxIter);
    alpha = 7;
    LocalSearchTries = 100;
    FlipSize = 0.25;
    NbrDiv = 12; %the number of divisions
    popSize = popSize-mod(popSize,NbrDiv);
    belta = 9;
    Dim = feature_num-1;
    Vmax = 0.6;
    thres = 0.6;

    %The number of particles (or size) of each division (DivSize) is calculated based on the population size (PopSize) and 
    % Ranking Features
    num_ins = train.numInstances;
    num_att = train.numAttributes;

    %数据的离散化处理
    if (train.attribute(0).isNumeric())
        disTransform = weka.filters.supervised.attribute.Discretize();
        disTransform.setUseBetterEncoding(true);
        disTransform.setInputFormat(train);
        dis_train = weka.filters.Filter.useFilter(train, disTransform);
    else
        dis_train = train;
    end

    train_matrix=zeros(train.numInstances(),train.numAttributes());
    dis_train_matrix=zeros(train.numInstances(),train.numAttributes());
    test_matrix=zeros(test.numInstances(),test.numAttributes());
    for di = 0:1:train.numInstances()-1
        for dj=0:1:train.numAttributes()-1
            train_matrix(di+1,dj+1) = train.instance(di).value(dj);
            dis_train_matrix(di+1,dj+1) = dis_train.instance(di).value(dj);
        end
    end
    for di = 0:1:test.numInstances()-1
        for dj=0:1:test.numAttributes()-1
            test_matrix(di+1,dj+1) = test.instance(di).value(dj);
        end
    end
    %计算suic
    suic=zeros(num_att-1,1);%初始化SUic的向量值为0
    for i=1:num_att-1
        suic(i)=SuCal(dis_train_matrix(:,i),dis_train_matrix(:,end));%计算每个特征的SUic值
    end
    [suic, indexsuic]=sort(suic,1,'descend');%将计算的SUic值降序排列
    train_matrix = train_matrix(:,[indexsuic' train.numAttributes()]);
    
    %初始化变长种群
    DivSize = floor(popSize/NbrDiv);
    pos = ones(popSize,Dim)*-inf;
    pbest_exampler = ones(popSize,Dim)*-inf;
    vel = ones(popSize,Dim)*-inf;
    fit = zeros(1,popSize);
    
    for div = 1:1:NbrDiv
        if div < NbrDiv
            parLen = floor(Dim*div/NbrDiv);
            parLens(1+DivSize*(div-1):1:DivSize*div) = parLen;
            pos(1+DivSize*(div-1):1:DivSize*div,1:1:parLen)=rand(DivSize,parLen);
            vel(1+DivSize*(div-1):1:DivSize*div,1:1:parLen)=-Vmax+rand(DivSize,parLen)*2*Vmax;
        else
            parLen = floor(Dim*div/NbrDiv);
            parLens(1+DivSize*(div-1):1:popSize) = parLen;
            pos(1+DivSize*(div-1):1:popSize,1:1:parLen)=rand(popSize-DivSize*(NbrDiv-1),parLen);
            vel(1+DivSize*(div-1):1:popSize,1:1:parLen)=-Vmax+rand(popSize-DivSize*(NbrDiv-1),parLen)*2*Vmax;
        end
    end
    %计算fitness
    % Objective function
    fun = @Fitness2; 
    for popi=1:1:popSize
        fit(popi) = fun(train_matrix,test_matrix,(pos(popi,:) > thres)); 
    end
    %更新pbest,gbest
    pbest=pos;
    pbestval=fit; %initialize the pbest and the pbest's fitness value
    [gbestval,gbestid]=min(pbestval);
    gbest=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
%     gbestrep=repmat(gbest,popSize,1);
    
    %计算每个粒子的Pc
    [~,bb] = sort(fit);
    [~,sorti] = sort(bb);
    Pc = 0.05+0.45*(exp((10*(sorti-1))/(popSize-1))/(exp(10)-1));
%     f_pbest=1:popSize;f_pbest=repmat(f_pbest',1,Dim);
    
    %为每个粒子分配exemplar
    for popi=1:1:popSize
        L = parLens(popi);
        ex_pbest_i = zeros(1,L);
        for li = 1:1:L
            if rand >= Pc(popi)
                ex_pbest_i(li) = popi;
            else
                fi1 = randi([sum(li>parLens)+1,popSize]);
                fi2 = randi([sum(li>parLens)+1,popSize]);
                if pbestval(fi1)<pbestval(fi2)
                    ex_pbest_i(li) = fi1;
                else
                    ex_pbest_i(li) = fi2;
                end
            end
            pbest_exampler(popi,li)=pbest(ex_pbest_i(li),li);
        end
    end
    
    iter = 1;
    stay_num_a = zeros(1,popSize);
    stay_p = false;
    stay_num_b = 0;
    while iter<=MaxIter
        %为每一个粒子构建exampler
        for popi=1:1:popSize
            L = parLens(popi);
            ex_pbest_i = zeros(1,L);
            if stay_num_a(1,popi)>alpha
                for li = 1:1:L
                    if rand >= Pc(popi)
                        ex_pbest_i(li) = popi;
                    else
                        fi1 = randi([sum(li>parLens)+1,popSize]);
                        fi2 = randi([sum(li>parLens)+1,popSize]);
                        if pbestval(fi1)<pbestval(fi2)
                            ex_pbest_i(li) = fi1;
                        else
                            ex_pbest_i(li) = fi2;
                        end
                    end
                    pbest_exampler(popi,li)=pbest(ex_pbest_i(li),li);
                end
                stay_num_a(1,popi)=0;
            end

            vel(popi,1:1:L)=w(iter).*vel(popi,1:1:L)+c1.*rand(1,L)...
                .*(pbest_exampler(popi,1:1:L)-pos(popi,1:1:L));
            vel(popi,1:1:L)=(vel(popi,1:1:L)>Vmax).*Vmax+(vel(popi,1:1:L)<=Vmax).*vel(popi,1:1:L);
            vel(popi,1:1:L)=(vel(popi,1:1:L)<(-Vmax)).*(-Vmax)+(vel(popi,1:1:L)>=(-Vmax)).*vel(popi,1:1:L);
            pos(popi,1:1:L)=pos(popi,1:1:L)+vel(popi,1:1:L);

            fit(popi) = fun(train_matrix,test_matrix,(pos(popi,:) > thres)); 

            %更新pbest和gbest
            if fit(popi)<pbestval(popi)
                pbestval(popi) = fit(popi);
                pbest(popi,:) = pos(popi,:);
                stay_num_a(1,popi) = 0;
            else
                stay_num_a(1,popi) = stay_num_a(1,popi) + 1;
                if stay_num_a(1,popi)>alpha
                    stay_p = true; 
                end 
            end

        end
        
                
        %****这里，我觉得原文中的Fig.4描述的可能有问题，因为LengthChanging函数中已经更新的Pc和Exenplar
        %****而LengthChanging函数之后又判断去执行一次完全没必要，[renewExmpl of any particles is true]
        %****应当在[gbest not improved for]前面执行，他的作用是为了pbest在多次为更新时重新分配Exempler。     
        if stay_p
            %计算每个粒子的Pc
            [~,bb] = sort(fit);
            [~,sorti] = sort(bb);
            Pc = 0.05+0.45*(exp((10*(sorti-1))/(popSize-1))/(exp(10)-1));
            stay_p = false;
        end
        
        %更新gbest
        [gbestval_tmp,gbestid_tmp]=min(pbestval);
        if gbestval_tmp<gbestval
            gbestval = gbestval_tmp;
            gbestid = gbestid_tmp;
            gbest = pbest(gbestid,:);
            stay_num_b = 0;
        else
            stay_num_b = stay_num_b + 1;
            if stay_num_b>belta %改变长度
                stay_num_b = 0;
                %(1)计算每一个div中的平均fitness
                fit_div = zeros(1,NbrDiv);
                for div = 1:1:NbrDiv
                    if div < NbrDiv
                        fit_div(div)=mean(fit(1+DivSize*(div-1):1:DivSize*div));
                    else
                        fit_div(div)=mean(fit(1+DivSize*(div-1):1:popSize));
                    end
                end
                [~,min_idx] = min(fit_div);
                pos([1+DivSize*(min_idx-1):1:DivSize*min_idx 1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv],:)...
                    =pos([1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv 1+DivSize*(min_idx-1):1:DivSize*min_idx],:);
                vel([1+DivSize*(min_idx-1):1:DivSize*min_idx 1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv],:)...
                    =vel([1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv 1+DivSize*(min_idx-1):1:DivSize*min_idx],:);
                pbest([1+DivSize*(min_idx-1):1:DivSize*min_idx 1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv],:)...
                    =pbest([1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv 1+DivSize*(min_idx-1):1:DivSize*min_idx],:);
                pbestval([1+DivSize*(min_idx-1):1:DivSize*min_idx 1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv])...
                    =pbestval([1+DivSize*(NbrDiv-1):1:DivSize*NbrDiv 1+DivSize*(min_idx-1):1:DivSize*min_idx]);
                Dim = parLens(DivSize*min_idx);
                for div = 1:1:NbrDiv
                    if div < NbrDiv
                        parLen = floor(Dim*div/NbrDiv);
                        parLens(1+DivSize*(div-1):1:DivSize*div) = parLen;
                        pos(1+DivSize*(div-1):1:DivSize*div,parLen+1:1:end)=-inf;
                        vel(1+DivSize*(div-1):1:DivSize*div,parLen+1:1:end)=-inf;
                    end
                end
                for popi = 1:1:popSize
                    fit(popi) = fun(train_matrix,test_matrix,(pos(popi,:) > thres)); 
                end
                %计算每个粒子的Pc
                [~,bb] = sort(fit);
                [~,sorti] = sort(bb);
                Pc = 0.05+0.45*(exp((10*(sorti-1))/(popSize-1))/(exp(10)-1));
                pbest=pos;
                pbestval=fit; %initialize the pbest and the pbest's fitness value
                
                %为每个粒子分配exemplar
                for popi=1:1:popSize
                    L = parLens(popi);
                    ex_pbest_i = zeros(1,L);
                    for li = 1:1:L
                        if rand >= Pc(popi)
                            ex_pbest_i(li) = popi;
                        else
                            fi1 = randi([sum(li>parLens)+1,popSize]);
                            fi2 = randi([sum(li>parLens)+1,popSize]);
                            if pbestval(fi1)<pbestval(fi2)
                                ex_pbest_i(li) = fi1;
                            else
                                ex_pbest_i(li) = fi2;
                            end
                        end
                        pbest_exampler(popi,li)=pbest(ex_pbest_i(li),li);
                    end
                end
                stay_num_a = zeros(1,popSize);
            end
        end
        
        
        iter = iter+1;
        fprintf('iter: %g',iter);
        gbestvals(iter)=gbestval;
        gbestval
    end
end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SU计算函数
function SU=SuCal(f1,f2)
    h1=h(f1);
    h2=h(f2);
    ig=mi(f1,f2);
    SU=2.0*ig/(h1+h2);
end
    
    
    
    
    
    
    
    